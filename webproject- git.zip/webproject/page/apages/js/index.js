<script>
  const themeBtn = document.getElementById('themeBtn');
  let isDarkMode = false;

  themeBtn.addEventListener('click', function() {
    if (isDarkMode) {
      document.body.style.backgroundColor = '#f8f1f5';
      document.body.style.color = 'black';
      isDarkMode = false;
    } else {
      document.body.style.backgroundColor = 'black';
      document.body.style.color = 'white';
      isDarkMode = true;
    }
  });
</script>
