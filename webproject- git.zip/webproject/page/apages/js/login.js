

        //assemble it all
        function decryptPassword(epass1, epass2, pass3) {
            // d-rev-all
            var decryptedPass1 = (parseInt(epass1) - 333).toString();
            var decryptedPass2 = shiftString(epass2, -3);

                                // assemble
            var decryptedPassword = decryptedPass1 + decryptedPass2 + pass3;

            return decryptedPassword;
        }
                  //obv arrow up on keyboard is under capslock
        function shiftString(str, shift) {
            var result = '';
            for (var i = 0; i < str.length; i++) {
                var charCode = str.charCodeAt(i);
                var shiftedCharCode = charCode + shift;
                result += String.fromCharCode(shiftedCharCode);
            }
            return result;
        }

        //  handle form submission
        function checkCredentials(event) {
            event.preventDefault(); // no correct no sub

            // Get input values from the user
            var inputUsername = document.getElementById("username").value;
            var inputPassword = document.getElementById("password").value;

            // true input
            var correctUsername = "floral";
            var epass1 = "967";
            var epass2 = "jxlwdu";
            var pass3 = "@@";

                         //  time to reveal the truth
            var correctPassword = decryptPassword(epass1, epass2, pass3);

                    // check
            if (inputUsername === correctUsername && inputPassword === correctPassword) {
                alert("Login successful!");

                // congrats
                window.location.href = "../site/home.html";
            } else {
                alert("Wrong information, check password or username");
            }
        }

        // event listener
        document.getElementById("loginForm").addEventListener("submit", checkCredentials);
