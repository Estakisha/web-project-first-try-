hello dr here are some important notes regarding login page


Login page - 

username : floral

password : 634guitar@@ 

(please make sure to check the box before continuing and if you entered one of the pages, please uncheck then recheck the box )
